```python
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
data = pd.read_csv("http://bit.ly/w-data")
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>9.2</td>
      <td>88</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.5</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.3</td>
      <td>81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2.7</td>
      <td>25</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.plot(x="Hours",y= "Scores", style ="o")
plt.title('Hours vs Scores')
plt.xlabel('Hours studied')
plt.ylabel('Scored')
plt.show()

```


![png](output_2_0.png)



```python
x = data.iloc[:,:-1].values
y = data.iloc[:,1].values

```


```python
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y , test_size=0.30 , random_state=0)
```


```python
from sklearn.linear_model import LinearRegression 
regressor = LinearRegression()  
regressor.fit(x_train, y_train)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)




```python
line=regressor.coef_*x+regressor.intercept_
plt.scatter(x,y)
plt.plot(x,line)
plt.show()
```


![png](output_6_0.png)



```python
print(x_test)
y_predict=regressor.predict(x_test)
```

    [[1.5]
     [3.2]
     [7.4]
     [2.5]
     [5.9]
     [3.8]
     [1.9]
     [7.8]]
    


```python
df = pd.DataFrame({'Actual': y_test, 'Predicted': y_predict})
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>17.053665</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.694229</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>74.806209</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.842232</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.123359</td>
    </tr>
    <tr>
      <th>5</th>
      <td>35</td>
      <td>39.567369</td>
    </tr>
    <tr>
      <th>6</th>
      <td>24</td>
      <td>20.969092</td>
    </tr>
    <tr>
      <th>7</th>
      <td>86</td>
      <td>78.721636</td>
    </tr>
  </tbody>
</table>
</div>




```python
hours=[[9.25]]
our_predict=regressor.predict(hours)
print("No of Hours = {}".format(hours))
print("Predicted Score = {}".format(our_predict[0]))
```

    No of Hours = [[9.25]]
    Predicted Score = 92.91505723477056
    


```python
from sklearn import metrics
print('Mean Absolute Error:', 
      metrics.mean_absolute_error(y_test, y_predict))
```

    Mean Absolute Error: 4.419727808027652
    


```python
from sklearn.metrics import mean_squared_error
from math import sqrt
rmse = sqrt(mean_squared_error(y_test, y_predict))
print(rmse)
```

    4.792191274636315
    


```python

```
